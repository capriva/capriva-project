autoreconf -vif
