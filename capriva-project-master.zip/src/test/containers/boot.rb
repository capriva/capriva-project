Dir.chdir File.expand_path('..', __FILE__)

require 'rubygems'
require 'bundler/setup'

require './coin_container'
